BPS - Paquete mejorado
Archivos incluidos:
- index.html
- catalogo.html
- contacto.html
- gracias.html
- styles.css

Cambios principales:
- styles.css reescrito con variables CSS, layout con Grid/Flex, animaciones y breakpoints.
- Catalogo y Contacto reorganizados: tarjetas generadas por JS para mejor responsividad.
- Formularios y botones con micro-interacciones y estados focus visibles.
- Video integrado y páginas listas para uso local.

Cómo usar:
Descomprime el ZIP y abre index.html en tu navegador. No se requieren servidores adicionales para las páginas estáticas.
